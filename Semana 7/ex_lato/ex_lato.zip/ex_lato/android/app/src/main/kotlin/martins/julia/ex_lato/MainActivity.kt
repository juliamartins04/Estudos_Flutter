package martins.julia.ex_lato

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
